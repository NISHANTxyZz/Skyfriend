package com.skyblockhp.skyfriends.listener;

import com.skyblockhp.skyfriends.SkyFriends;
import com.skyblockhp.skyfriends.data.FriendRepository;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public final class PlayerListener implements Listener {
    private final SkyFriends plugin; private final FriendRepository repo;
    public PlayerListener(SkyFriends plugin,FriendRepository repo){this.plugin=plugin;this.repo=repo;}
    @EventHandler public void onJoin(PlayerJoinEvent e){
        Player p=e.getPlayer();repo.touch(p.getUniqueId(),p.getName());
        long expiry=plugin.getConfig().getLong("settings.request-expiry-seconds",300)*1000L;
        repo.expireRequests(expiry);
        if(!plugin.getConfig().getBoolean("settings.friend-join-notifications",true))return;
        for(UUID id:repo.friends(p.getUniqueId(),false)){
            Player friend=Bukkit.getPlayer(id);
            if(friend!=null&&repo.notificationsEnabled(friend.getUniqueId()))friend.sendMessage(SkyFriends.color("&a[Friends] &f"+p.getName()+" &eis now online."));
        }
    }
    @EventHandler public void onQuit(PlayerQuitEvent e){
        Player p=e.getPlayer();
        if(!plugin.getConfig().getBoolean("settings.friend-leave-notifications",true))return;
        for(UUID id:repo.friends(p.getUniqueId(),false)){
            Player friend=Bukkit.getPlayer(id);
            if(friend!=null&&repo.notificationsEnabled(friend.getUniqueId()))friend.sendMessage(SkyFriends.color("&a[Friends] &f"+p.getName()+" &eis now offline."));
        }
    }
}
