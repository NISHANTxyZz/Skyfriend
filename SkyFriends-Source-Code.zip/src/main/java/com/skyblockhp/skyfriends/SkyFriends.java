package com.skyblockhp.skyfriends;

import com.skyblockhp.skyfriends.command.FriendCommand;
import com.skyblockhp.skyfriends.command.FriendAdminCommand;
import com.skyblockhp.skyfriends.command.IgnoreCommand;
import com.skyblockhp.skyfriends.command.PrivacyCommand;
import com.skyblockhp.skyfriends.data.FriendRepository;
import com.skyblockhp.skyfriends.gui.FriendGui;
import com.skyblockhp.skyfriends.listener.PlayerListener;
import org.bukkit.plugin.java.JavaPlugin;

public final class SkyFriends extends JavaPlugin {
    private FriendRepository repository;
    private FriendGui friendGui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            repository = new FriendRepository(this);
            repository.initialize();
        } catch (Exception ex) {
            getLogger().severe("Could not initialize SQLite: " + ex.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        friendGui = new FriendGui(this, repository);
        FriendCommand friendCommand = new FriendCommand(this, repository, friendGui);
        getCommand("friend").setExecutor(friendCommand);
        getCommand("friend").setTabCompleter(friendCommand);
        getCommand("ignore").setExecutor(new IgnoreCommand(this, repository));
        getCommand("privacy").setExecutor(new PrivacyCommand(this, repository, friendGui));
        FriendAdminCommand admin = new FriendAdminCommand(this, repository);
        getCommand("friendadmin").setExecutor(admin);
        getCommand("friendadmin").setTabCompleter(admin);
        getServer().getPluginManager().registerEvents(new PlayerListener(this, repository), this);
        getServer().getPluginManager().registerEvents(friendGui, this);
        getLogger().info("SkyFriends enabled.");
    }

    @Override
    public void onDisable() {
        if (repository != null) repository.close();
    }

    public String message(String key) {
        String raw = getConfig().getString("messages." + key, "&cMissing message: " + key);
        return color(getConfig().getString("messages.prefix", "") + raw);
    }

    public String rawMessage(String key) {
        return color(getConfig().getString("messages." + key, "&cMissing message: " + key));
    }

    public static String color(String text) {
        return org.bukkit.ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    public FriendRepository repository() { return repository; }
}
