package com.skyblockhp.skyfriends.data;

import com.skyblockhp.skyfriends.SkyFriends;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;

import java.io.File;
import java.sql.*;
import java.util.*;

public final class FriendRepository {
    private final SkyFriends plugin;
    private Connection connection;

    public FriendRepository(SkyFriends plugin) { this.plugin = plugin; }

    public synchronized void initialize() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
            File db = new File(plugin.getDataFolder(), plugin.getConfig().getString("settings.database-file", "friends.db"));
            if (!plugin.getDataFolder().exists() && !plugin.getDataFolder().mkdirs()) {
                throw new SQLException("Could not create plugin data folder");
            }
            connection = DriverManager.getConnection("jdbc:sqlite:" + db.getAbsolutePath());
            try (Statement s = connection.createStatement()) {
                s.executeUpdate("PRAGMA foreign_keys = ON");
                s.executeUpdate("CREATE TABLE IF NOT EXISTS players (uuid TEXT PRIMARY KEY, name TEXT NOT NULL, requests_enabled INTEGER NOT NULL DEFAULT 1, notifications INTEGER NOT NULL DEFAULT 1)");
                s.executeUpdate("CREATE TABLE IF NOT EXISTS friends (uuid_low TEXT NOT NULL, uuid_high TEXT NOT NULL, created_at INTEGER NOT NULL, best_low INTEGER NOT NULL DEFAULT 0, best_high INTEGER NOT NULL DEFAULT 0, nick_low TEXT, nick_high TEXT, PRIMARY KEY(uuid_low, uuid_high))");
                s.executeUpdate("CREATE TABLE IF NOT EXISTS requests (sender TEXT NOT NULL, receiver TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(sender, receiver))");
                s.executeUpdate("CREATE TABLE IF NOT EXISTS ignores (owner TEXT NOT NULL, target TEXT NOT NULL, PRIMARY KEY(owner, target))");
            }
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite JDBC driver missing", e);
        }
    }

    public synchronized void close() {
        try { if (connection != null && !connection.isClosed()) connection.close(); }
        catch (SQLException e) { plugin.getLogger().warning("Error closing SQLite: " + e.getMessage()); }
    }

    private synchronized void ensurePlayer(UUID uuid, String name) throws SQLException {
        try (PreparedStatement p = connection.prepareStatement("INSERT INTO players(uuid,name) VALUES(?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name")) {
            p.setString(1, uuid.toString()); p.setString(2, name); p.executeUpdate();
        }
    }

    public synchronized void touch(UUID uuid, String name) {
        try { ensurePlayer(uuid, name); } catch (SQLException e) { error(e); }
    }

    public synchronized String knownName(UUID uuid) {
        try (PreparedStatement p = connection.prepareStatement("SELECT name FROM players WHERE uuid=?")) {
            p.setString(1, uuid.toString());
            try (ResultSet r = p.executeQuery()) { if (r.next()) return r.getString(1); }
        } catch (SQLException e) { error(e); }
        OfflinePlayer op = Bukkit.getOfflinePlayer(uuid);
        return op.getName() == null ? uuid.toString().substring(0, 8) : op.getName();
    }

    public synchronized UUID findKnownUuid(String name) {
        try (PreparedStatement p = connection.prepareStatement("SELECT uuid FROM players WHERE name = ? COLLATE NOCASE ORDER BY rowid DESC LIMIT 1")) {
            p.setString(1, name);
            try (ResultSet r = p.executeQuery()) { if (r.next()) return UUID.fromString(r.getString(1)); }
        } catch (SQLException e) { error(e); }
        return null;
    }

    public synchronized boolean areFriends(UUID a, UUID b) {
        String[] pair = pair(a,b);
        try (PreparedStatement p = connection.prepareStatement("SELECT 1 FROM friends WHERE uuid_low=? AND uuid_high=?")) {
            p.setString(1,pair[0]); p.setString(2,pair[1]);
            try (ResultSet r=p.executeQuery()) { return r.next(); }
        } catch (SQLException e) { error(e); return false; }
    }

    public synchronized int friendCount(UUID uuid) {
        try (PreparedStatement p = connection.prepareStatement("SELECT COUNT(*) FROM friends WHERE uuid_low=? OR uuid_high=?")) {
            p.setString(1,uuid.toString()); p.setString(2,uuid.toString());
            try (ResultSet r=p.executeQuery()) { return r.next() ? r.getInt(1) : 0; }
        } catch (SQLException e) { error(e); return 0; }
    }

    public synchronized boolean requestsEnabled(UUID uuid) {
        try (PreparedStatement p = connection.prepareStatement("SELECT requests_enabled FROM players WHERE uuid=?")) {
            p.setString(1,uuid.toString());
            try (ResultSet r=p.executeQuery()) { return !r.next() || r.getInt(1) == 1; }
        } catch (SQLException e) { error(e); return true; }
    }

    public synchronized boolean notificationsEnabled(UUID uuid) {
        try (PreparedStatement p = connection.prepareStatement("SELECT notifications FROM players WHERE uuid=?")) {
            p.setString(1,uuid.toString());
            try (ResultSet r=p.executeQuery()) { return !r.next() || r.getInt(1) == 1; }
        } catch (SQLException e) { error(e); return true; }
    }

    public synchronized boolean toggleRequests(UUID uuid, String name) {
        touch(uuid,name);
        boolean enabled = !requestsEnabled(uuid);
        updatePlayerFlag(uuid, "requests_enabled", enabled);
        return enabled;
    }

    public synchronized boolean toggleNotifications(UUID uuid, String name) {
        touch(uuid,name);
        boolean enabled = !notificationsEnabled(uuid);
        updatePlayerFlag(uuid, "notifications", enabled);
        return enabled;
    }

    private void updatePlayerFlag(UUID uuid, String column, boolean value) {
        if (!column.equals("requests_enabled") && !column.equals("notifications")) return;
        try (PreparedStatement p = connection.prepareStatement("UPDATE players SET " + column + "=? WHERE uuid=?")) {
            p.setInt(1,value?1:0); p.setString(2,uuid.toString()); p.executeUpdate();
        } catch (SQLException e) { error(e); }
    }

    public synchronized boolean isIgnored(UUID owner, UUID target) {
        try (PreparedStatement p=connection.prepareStatement("SELECT 1 FROM ignores WHERE owner=? AND target=?")) {
            p.setString(1,owner.toString()); p.setString(2,target.toString());
            try(ResultSet r=p.executeQuery()){return r.next();}
        } catch(SQLException e){error(e);return false;}
    }

    public synchronized boolean addIgnore(UUID owner, UUID target) { return executePair("INSERT OR IGNORE INTO ignores(owner,target) VALUES(?,?)", owner,target); }
    public synchronized boolean removeIgnore(UUID owner, UUID target) { return executePair("DELETE FROM ignores WHERE owner=? AND target=?", owner,target); }

    public synchronized List<UUID> ignored(UUID owner) {
        List<UUID> out=new ArrayList<>();
        try(PreparedStatement p=connection.prepareStatement("SELECT target FROM ignores WHERE owner=? ORDER BY rowid")) {
            p.setString(1,owner.toString()); try(ResultSet r=p.executeQuery()){while(r.next())out.add(UUID.fromString(r.getString(1)));}
        } catch(SQLException e){error(e);} return out;
    }

    private boolean executePair(String sql, UUID a, UUID b) {
        try(PreparedStatement p=connection.prepareStatement(sql)){p.setString(1,a.toString());p.setString(2,b.toString());return p.executeUpdate()>0;}
        catch(SQLException e){error(e);return false;}
    }

    public synchronized boolean sendRequest(UUID sender, String senderName, UUID receiver, String receiverName) {
        touch(sender,senderName); touch(receiver,receiverName);
        try(PreparedStatement p=connection.prepareStatement("INSERT INTO requests(sender,receiver,created_at) VALUES(?,?,?) ON CONFLICT(sender,receiver) DO UPDATE SET created_at=excluded.created_at")) {
            p.setString(1,sender.toString());p.setString(2,receiver.toString());p.setLong(3,System.currentTimeMillis());p.executeUpdate();return true;
        } catch(SQLException e){error(e);return false;}
    }

    public synchronized long requestTime(UUID sender, UUID receiver) {
        try(PreparedStatement p=connection.prepareStatement("SELECT created_at FROM requests WHERE sender=? AND receiver=?")) {
            p.setString(1,sender.toString());p.setString(2,receiver.toString());try(ResultSet r=p.executeQuery()){return r.next()?r.getLong(1):0;}
        } catch(SQLException e){error(e);return 0;}
    }

    public synchronized List<UUID> requestsTo(UUID receiver) { return uuidList("SELECT sender FROM requests WHERE receiver=? ORDER BY created_at", receiver); }
    public synchronized List<UUID> requestsFrom(UUID sender) { return uuidList("SELECT receiver FROM requests WHERE sender=? ORDER BY created_at", sender); }
    private List<UUID> uuidList(String sql, UUID uuid) {
        List<UUID> out=new ArrayList<>();
        try(PreparedStatement p=connection.prepareStatement(sql)){p.setString(1,uuid.toString());try(ResultSet r=p.executeQuery()){while(r.next())out.add(UUID.fromString(r.getString(1)));}}
        catch(SQLException e){error(e);}return out;
    }

    public synchronized boolean deleteRequest(UUID sender, UUID receiver) { return executePair("DELETE FROM requests WHERE sender=? AND receiver=?",sender,receiver); }
    public synchronized void expireRequests(long expiryMillis) {
        try(PreparedStatement p=connection.prepareStatement("DELETE FROM requests WHERE created_at < ?")){p.setLong(1,System.currentTimeMillis()-expiryMillis);p.executeUpdate();}
        catch(SQLException e){error(e);}
    }

    public synchronized boolean addFriend(UUID a, String aName, UUID b, String bName) {
        touch(a,aName);touch(b,bName);String[] pair=pair(a,b);
        try(PreparedStatement p=connection.prepareStatement("INSERT OR IGNORE INTO friends(uuid_low,uuid_high,created_at) VALUES(?,?,?)")) {
            p.setString(1,pair[0]);p.setString(2,pair[1]);p.setLong(3,System.currentTimeMillis());return p.executeUpdate()>0;
        }catch(SQLException e){error(e);return false;}
    }

    public synchronized boolean removeFriend(UUID a, UUID b) {
        String[] pair=pair(a,b);
        try(PreparedStatement p=connection.prepareStatement("DELETE FROM friends WHERE uuid_low=? AND uuid_high=?")) {
            p.setString(1,pair[0]);p.setString(2,pair[1]);return p.executeUpdate()>0;
        }catch(SQLException e){error(e);return false;}
    }

    public synchronized List<UUID> friends(UUID uuid, boolean bestOnly) {
        List<UUID> out=new ArrayList<>();
        String sql="SELECT CASE WHEN uuid_low=? THEN uuid_high ELSE uuid_low END AS other FROM friends WHERE (uuid_low=? OR uuid_high=?)";
        try(PreparedStatement p=connection.prepareStatement(sql)) {
            p.setString(1,uuid.toString());p.setString(2,uuid.toString());p.setString(3,uuid.toString());
            try(ResultSet r=p.executeQuery()){while(r.next())out.add(UUID.fromString(r.getString("other")));}
        }catch(SQLException e){error(e);}
        out.sort(Comparator.comparing(n -> knownName(n),String.CASE_INSENSITIVE_ORDER));
        return out;
    }

    public synchronized void toggleBest(UUID owner, UUID target) {
        String[] pair=pair(owner,target);boolean low=owner.toString().equals(pair[0]);
        String col=low?"best_low":"best_high";
        try(PreparedStatement p=connection.prepareStatement("UPDATE friends SET "+col+"=CASE "+col+" WHEN 1 THEN 0 ELSE 1 END WHERE uuid_low=? AND uuid_high=?")) {
            p.setString(1,pair[0]);p.setString(2,pair[1]);p.executeUpdate();
        }catch(SQLException e){error(e);}
    }

    public synchronized boolean isBest(UUID owner, UUID target) {
        String[] pair=pair(owner,target);boolean low=owner.toString().equals(pair[0]);
        String col=low?"best_low":"best_high";
        try(PreparedStatement p=connection.prepareStatement("SELECT "+col+" FROM friends WHERE uuid_low=? AND uuid_high=?")) {
            p.setString(1,pair[0]);p.setString(2,pair[1]);try(ResultSet r=p.executeQuery()){return r.next()&&r.getInt(1)==1;}
        }catch(SQLException e){error(e);return false;}
    }

    public synchronized void setNickname(UUID owner, UUID target, String nickname) {
        String[] pair=pair(owner,target);boolean low=owner.toString().equals(pair[0]);String col=low?"nick_low":"nick_high";
        try(PreparedStatement p=connection.prepareStatement("UPDATE friends SET "+col+"=? WHERE uuid_low=? AND uuid_high=?")) {
            p.setString(1,nickname);p.setString(2,pair[0]);p.setString(3,pair[1]);p.executeUpdate();
        }catch(SQLException e){error(e);}
    }

    public synchronized String nickname(UUID owner, UUID target) {
        String[] pair=pair(owner,target);boolean low=owner.toString().equals(pair[0]);String col=low?"nick_low":"nick_high";
        try(PreparedStatement p=connection.prepareStatement("SELECT "+col+" FROM friends WHERE uuid_low=? AND uuid_high=?")) {
            p.setString(1,pair[0]);p.setString(2,pair[1]);try(ResultSet r=p.executeQuery()){return r.next()?r.getString(1):null;}
        }catch(SQLException e){error(e);return null;}
    }

    public synchronized void removeAll(UUID owner) {
        try(PreparedStatement p=connection.prepareStatement("DELETE FROM friends WHERE uuid_low=? OR uuid_high=?")){p.setString(1,owner.toString());p.setString(2,owner.toString());p.executeUpdate();}
        catch(SQLException e){error(e);}
        try(PreparedStatement p=connection.prepareStatement("DELETE FROM requests WHERE sender=? OR receiver=?")){p.setString(1,owner.toString());p.setString(2,owner.toString());p.executeUpdate();}
        catch(SQLException e){error(e);}
    }

    public synchronized int pendingCount(UUID owner) { return requestsTo(owner).size(); }

    private String[] pair(UUID a, UUID b) {
        return a.toString().compareTo(b.toString()) < 0 ? new String[]{a.toString(),b.toString()} : new String[]{b.toString(),a.toString()};
    }
    private void error(SQLException e) { plugin.getLogger().warning("SQLite operation failed: " + e.getMessage()); }
}
