package com.skyblockhp.skyfriends.util;

import com.skyblockhp.skyfriends.SkyFriends;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.hover.content.Text;

public final class Chat {
    private Chat() {}
    public static void send(SkyFriends plugin, org.bukkit.command.CommandSender sender, String key) {
        sender.sendMessage(plugin.message(key));
    }
    public static void clickable(org.bukkit.entity.Player player, String text, String hover, String command) {
        TextComponent component = new TextComponent(SkyFriends.color(text));
        component.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, command));
        component.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new Text(SkyFriends.color(hover))));
        player.spigot().sendMessage(component);
    }
    public static void line(org.bukkit.entity.Player player, String text) { player.sendMessage(SkyFriends.color(text)); }
}
