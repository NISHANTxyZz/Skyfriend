package com.skyblockhp.skyfriends.command;

import com.skyblockhp.skyfriends.SkyFriends;
import com.skyblockhp.skyfriends.data.FriendRepository;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;

public final class FriendAdminCommand implements CommandExecutor,TabCompleter {
    private final SkyFriends plugin; private final FriendRepository repo;
    public FriendAdminCommand(SkyFriends plugin,FriendRepository repo){this.plugin=plugin;this.repo=repo;}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!sender.hasPermission("skyfriends.admin")){sender.sendMessage(plugin.message("no-permission"));return true;}
        if(args.length==0){sender.sendMessage(SkyFriends.color("&e/friendadmin reload | info <player>"));return true;}
        if(args[0].equalsIgnoreCase("reload")){
            plugin.reloadConfig();sender.sendMessage(plugin.message("reload"));return true;
        }
        if(args[0].equalsIgnoreCase("info")&&args.length>1){
            Player p=Bukkit.getPlayerExact(args[1]);UUID id=p!=null?p.getUniqueId():repo.findKnownUuid(args[1]);
            if(id==null){sender.sendMessage(plugin.message("player-not-found"));return true;}
            sender.sendMessage(SkyFriends.color("&6SkyFriends info: &f"+repo.knownName(id)+" &7friends=&f"+repo.friendCount(id)+" &7requests-enabled=&f"+repo.requestsEnabled(id)));
            return true;
        }
        sender.sendMessage(SkyFriends.color("&e/friendadmin reload | info <player>"));return true;
    }
    @Override public List<String> onTabComplete(CommandSender s,Command c,String a,String[] args){
        if(args.length==1)return List.of("reload","info");
        if(args.length==2&&args[0].equalsIgnoreCase("info"))return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        return Collections.emptyList();
    }
}
