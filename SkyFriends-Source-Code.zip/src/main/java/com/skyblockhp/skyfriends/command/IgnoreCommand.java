package com.skyblockhp.skyfriends.command;

import com.skyblockhp.skyfriends.SkyFriends;
import com.skyblockhp.skyfriends.data.FriendRepository;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.UUID;

public final class IgnoreCommand implements CommandExecutor {
    private final SkyFriends plugin; private final FriendRepository repo;
    public IgnoreCommand(SkyFriends plugin,FriendRepository repo){this.plugin=plugin;this.repo=repo;}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!(sender instanceof Player p)){sender.sendMessage("Players only.");return true;}
        if(!p.hasPermission("skyfriends.use")){p.sendMessage(plugin.message("no-permission"));return true;}
        if(args.length==0||args[0].equalsIgnoreCase("list")){
            p.sendMessage(SkyFriends.color("&6&lIgnored players"));
            if(repo.ignored(p.getUniqueId()).isEmpty())p.sendMessage(plugin.message("list-empty"));
            for(UUID id:repo.ignored(p.getUniqueId()))p.sendMessage(SkyFriends.color("&7- "+repo.knownName(id)));
            return true;
        }
        if(args.length<2){p.sendMessage(SkyFriends.color("&cUsage: /ignore <add|remove|list> <player>"));return true;}
        Player online=Bukkit.getPlayerExact(args[1]);UUID target=online!=null?online.getUniqueId():repo.findKnownUuid(args[1]);
        if(target==null){p.sendMessage(plugin.message("player-not-found"));return true;}
        if(target.equals(p.getUniqueId())){p.sendMessage(plugin.message("self"));return true;}
        if(args[0].equalsIgnoreCase("add")){
            if(repo.addIgnore(p.getUniqueId(),target))p.sendMessage(plugin.message("ignore-added").replace("%player%",repo.knownName(target)));
            else p.sendMessage(plugin.message("ignored-already"));
        }else if(args[0].equalsIgnoreCase("remove")){
            if(repo.removeIgnore(p.getUniqueId(),target))p.sendMessage(plugin.message("ignore-removed").replace("%player%",repo.knownName(target)));
            else p.sendMessage(plugin.message("not-ignored"));
        }else p.sendMessage(SkyFriends.color("&cUsage: /ignore <add|remove|list> [player]"));
        return true;
    }
}
