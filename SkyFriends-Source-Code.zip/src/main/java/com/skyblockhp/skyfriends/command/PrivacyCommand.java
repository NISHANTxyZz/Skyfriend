package com.skyblockhp.skyfriends.command;

import com.skyblockhp.skyfriends.SkyFriends;
import com.skyblockhp.skyfriends.data.FriendRepository;
import com.skyblockhp.skyfriends.gui.FriendGui;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public final class PrivacyCommand implements CommandExecutor {
    private final SkyFriends plugin; private final FriendRepository repo; private final FriendGui gui;
    public PrivacyCommand(SkyFriends plugin,FriendRepository repo,FriendGui gui){this.plugin=plugin;this.repo=repo;this.gui=gui;}
    @Override public boolean onCommand(CommandSender sender,Command command,String label,String[] args){
        if(!(sender instanceof Player p)){sender.sendMessage("Players only.");return true;}
        if(!p.hasPermission("skyfriends.use")){p.sendMessage(plugin.message("no-permission"));return true;}
        gui.openPrivacy(p);
        return true;
    }
}
