package com.skyblockhp.skyfriends.command;

import com.skyblockhp.skyfriends.SkyFriends;
import com.skyblockhp.skyfriends.data.FriendRepository;
import com.skyblockhp.skyfriends.gui.FriendGui;
import com.skyblockhp.skyfriends.util.Chat;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

public final class FriendCommand implements CommandExecutor, TabCompleter {
    private final SkyFriends plugin;
    private final FriendRepository repo;
    private final FriendGui gui;

    public FriendCommand(SkyFriends plugin, FriendRepository repo, FriendGui gui) {
        this.plugin=plugin;this.repo=repo;this.gui=gui;
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("skyfriends.use")) { Chat.send(plugin,sender,"no-permission"); return true; }
        if (!(sender instanceof Player p)) { sender.sendMessage("Players only."); return true; }
        repo.touch(p.getUniqueId(),p.getName());
        if (args.length==0) { gui.openFriends(p,0); return true; }
        String sub=args[0].toLowerCase(Locale.ROOT);
        switch(sub) {
            case "help" -> help(p);
            case "add" -> add(p,args);
            case "accept" -> accept(p,args);
            case "deny" -> deny(p,args);
            case "remove" -> remove(p,args);
            case "removeall" -> {
                if(args.length>1 && args[1].equalsIgnoreCase("confirm")) {
                    repo.removeAll(p.getUniqueId());p.sendMessage(SkyFriends.color("&aAll friendships and pending requests removed."));
                } else Chat.line(p,"&cThis removes all friendships and pending requests. Run &f/friend removeall confirm&c to proceed.");
            }
            case "list" -> list(p,args);
            case "requests" -> requests(p,args);
            case "toggle" -> {
                boolean on=repo.toggleRequests(p.getUniqueId(),p.getName());
                Chat.send(plugin,p,on?"toggle-on":"toggle-off");
            }
            case "notifications" -> {
                boolean on=repo.toggleNotifications(p.getUniqueId(),p.getName());
                Chat.send(plugin,p,on?"notifications-on":"notifications-off");
            }
            case "best" -> best(p,args);
            case "nickname" -> nickname(p,args);
            case "menu" -> gui.openFriends(p,0);
            default -> help(p);
        }
        return true;
    }

    private void add(Player p,String[] a) {
        if(a.length<2){Chat.line(p,"&cUsage: /friend add <player>");return;}
        UUID targetId=resolve(a[1]);
        if(targetId==null){Chat.send(plugin,p,"player-not-found");return;}
        if(targetId.equals(p.getUniqueId())){Chat.send(plugin,p,"self");return;}
        String targetName=repo.knownName(targetId);
        if(repo.areFriends(p.getUniqueId(),targetId)){Chat.send(plugin,p,"already-friends");return;}
        if(repo.isIgnored(p.getUniqueId(),targetId)||repo.isIgnored(targetId,p.getUniqueId())){Chat.send(plugin,p,"ignored");return;}
        if(!repo.requestsEnabled(targetId)){Chat.send(plugin,p,"requests-disabled");return;}
        int limit=plugin.getConfig().getInt("settings.default-friend-limit",100);
        if(!p.hasPermission("skyfriends.bypass.limit")&&repo.friendCount(p.getUniqueId())>=limit){Chat.send(plugin,p,"limit-reached");return;}
        long pending=repo.requestTime(p.getUniqueId(),targetId);
        if(pending>0){Chat.line(p,"&eYou already sent a request to &f"+targetName+"&e.");return;}
        if(repo.requestTime(targetId,p.getUniqueId())>0){accept(p,new String[]{"accept",targetName});return;}
        repo.sendRequest(p.getUniqueId(),p.getName(),targetId,targetName);
        p.sendMessage(plugin.message("request-sent").replace("%player%",targetName));
        Player target=Bukkit.getPlayer(targetId);
        if(target!=null) {
            target.sendMessage(plugin.message("request-received").replace("%player%",p.getName()));
            Chat.clickable(target,"&a&l[ACCEPT]","&aAccept friend request","/friend accept "+p.getName());
            Chat.clickable(target," &c&l[DENY]","&cDeny friend request","/friend deny "+p.getName());
            Chat.clickable(target," &7&l[IGNORE]","&7Ignore this player","/ignore add "+p.getName());
        }
    }

    private void accept(Player p,String[] a) {
        if(a.length<2){Chat.line(p,"&cUsage: /friend accept <player>");return;}
        UUID other=resolve(a[1]); if(other==null){Chat.send(plugin,p,"player-not-found");return;}
        long created=repo.requestTime(other,p.getUniqueId());
        if(created==0){Chat.send(plugin,p,"request-not-found");return;}
        long expiry=plugin.getConfig().getLong("settings.request-expiry-seconds",300)*1000L;
        if(System.currentTimeMillis()-created>expiry){repo.deleteRequest(other,p.getUniqueId());Chat.send(plugin,p,"request-expired");return;}
        int limit=plugin.getConfig().getInt("settings.default-friend-limit",100);
        if(!p.hasPermission("skyfriends.bypass.limit")&&repo.friendCount(p.getUniqueId())>=limit){Chat.send(plugin,p,"limit-reached");return;}
        String otherName=repo.knownName(other);
        repo.deleteRequest(other,p.getUniqueId());
        repo.deleteRequest(p.getUniqueId(),other);
        repo.addFriend(p.getUniqueId(),p.getName(),other,otherName);
        p.sendMessage(plugin.message("request-accepted").replace("%player%",otherName));
        Player online=Bukkit.getPlayer(other);
        if(online!=null)online.sendMessage(plugin.message("request-accepted").replace("%player%",p.getName()));
    }

    private void deny(Player p,String[] a) {
        if(a.length<2){Chat.line(p,"&cUsage: /friend deny <player>");return;}
        UUID other=resolve(a[1]);if(other==null){Chat.send(plugin,p,"player-not-found");return;}
        if(repo.deleteRequest(other,p.getUniqueId()))p.sendMessage(plugin.message("request-denied").replace("%player%",repo.knownName(other)));
        else Chat.send(plugin,p,"request-not-found");
    }

    private void remove(Player p,String[] a) {
        if(a.length<2){Chat.line(p,"&cUsage: /friend remove <player>");return;}
        UUID other=resolve(a[1]);if(other==null){Chat.send(plugin,p,"player-not-found");return;}
        if(repo.removeFriend(p.getUniqueId(),other)){
            p.sendMessage(plugin.message("friend-removed").replace("%player%",repo.knownName(other)));
            Player online=Bukkit.getPlayer(other);if(online!=null)online.sendMessage(SkyFriends.color("&e"+p.getName()+" removed you from their friends."));
        } else Chat.send(plugin,p,"not-friends");
    }

    private void list(Player p,String[] a) {
        int page=parsePage(a,1)-1;
        List<UUID> friends=repo.friends(p.getUniqueId(),false);
        int size=Math.max(1,plugin.getConfig().getInt("settings.list-page-size",45));
        int pages=Math.max(1,(friends.size()+size-1)/size);page=Math.max(0,Math.min(page,pages-1));
        Chat.line(p,"&6&lFriends &7("+friends.size()+") &8— &7Page "+(page+1)+"/"+pages);
        if(friends.isEmpty()){Chat.send(plugin,p,"list-empty");return;}
        for(UUID id:friends.subList(page*size,Math.min(friends.size(),(page+1)*size))){
            Player online=Bukkit.getPlayer(id);
            boolean best=repo.isBest(p.getUniqueId(),id);
            String name=repo.nickname(p.getUniqueId(),id);
            if(name==null||name.isBlank())name=repo.knownName(id);
            Chat.line(p,(online!=null?"&a● ":"&7● ")+(best?"&6★ ":"")+name+(online!=null?" &a(Online)":" &7(Offline)"));
        }
        if(page>0)Chat.clickable(p,"&e[Previous]","&ePrevious page","/friend list "+page);
        if(page+1<pages)Chat.clickable(p," &e[Next]","&eNext page","/friend list "+(page+2));
    }

    private void requests(Player p,String[] a) {
        int page=parsePage(a,1)-1;
        List<UUID> incoming=repo.requestsTo(p.getUniqueId());
        List<UUID> outgoing=repo.requestsFrom(p.getUniqueId());
        Chat.line(p,"&6&lIncoming requests &7("+incoming.size()+")");
        if(incoming.isEmpty())Chat.line(p,"&7None");
        int start=Math.max(0,page*10),end=Math.min(incoming.size(),start+10);
        for(UUID id:incoming.subList(Math.min(start,incoming.size()),end)){
            String name=repo.knownName(id);
            Chat.clickable(p,"&a"+name+" &7[Accept]","&aAccept request","/friend accept "+name);
            Chat.clickable(p," &c[Deny]","&cDeny request","/friend deny "+name);
        }
        Chat.line(p,"&6&lOutgoing requests &7("+outgoing.size()+")");
        if(outgoing.isEmpty())Chat.line(p,"&7None");
        for(UUID id:outgoing.subList(Math.min(start,outgoing.size()),Math.min(outgoing.size(),start+10))){
            Chat.line(p,"&e"+repo.knownName(id)+" &7(pending)");
        }
        if(incoming.size()>10||outgoing.size()>10){
            if(page>0)Chat.clickable(p,"&e[Previous]","&ePrevious page","/friend requests "+page);
            if((page+1)*10<Math.max(incoming.size(),outgoing.size()))Chat.clickable(p," &e[Next]","&eNext page","/friend requests "+(page+2));
        }
    }

    private void best(Player p,String[] a) {
        if(a.length<2){Chat.line(p,"&cUsage: /friend best <player>");return;}
        UUID other=resolve(a[1]);if(other==null||!repo.areFriends(p.getUniqueId(),other)){Chat.send(plugin,p,"not-friends");return;}
        repo.toggleBest(p.getUniqueId(),other);
        Chat.line(p,repo.isBest(p.getUniqueId(),other)?"&aMarked as best friend.":"&eBest friend removed.");
    }

    private void nickname(Player p,String[] a) {
        if(a.length<3){Chat.line(p,"&cUsage: /friend nickname <player> <nickname|clear>");return;}
        UUID other=resolve(a[1]);if(other==null||!repo.areFriends(p.getUniqueId(),other)){Chat.send(plugin,p,"not-friends");return;}
        String nick=String.join(" ",Arrays.copyOfRange(a,2,a.length));
        if(nick.equalsIgnoreCase("clear"))nick=null;
        else if(nick.length()>24){Chat.line(p,"&cNickname must be 24 characters or fewer.");return;}
        repo.setNickname(p.getUniqueId(),other,nick);
        Chat.line(p,"&aNickname updated.");
    }

    private UUID resolve(String name) {
        Player online=Bukkit.getPlayerExact(name);if(online!=null){repo.touch(online.getUniqueId(),online.getName());return online.getUniqueId();}
        return repo.findKnownUuid(name);
    }
    private int parsePage(String[] a,int fallback){if(a.length<2)return fallback;try{return Math.max(1,Integer.parseInt(a[1]));}catch(NumberFormatException e){return fallback;}}
    private void help(Player p) {
        Chat.line(p,"&6&lSkyFriends &7Commands");
        for(String s:List.of("&e/friend add <player> &7- Send a request","&e/friend accept|deny <player>","&e/friend remove <player>","&e/friend list [page]","&e/friend requests [page]","&e/friend best <player>","&e/friend nickname <player> <name|clear>","&e/friend toggle","&e/friend notifications","&e/friend removeall confirm","&e/ignore <add|remove|list> [player]","&e/privacy","&e/friend menu"))Chat.line(p,s);
    }

    @Override public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if(args.length==1)return List.of("add","accept","deny","remove","removeall","list","requests","best","nickname","toggle","notifications","menu","help").stream().filter(s->s.startsWith(args[0].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        if(args.length==2&&List.of("add","accept","deny","remove","best","nickname").contains(args[0].toLowerCase(Locale.ROOT)))
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).filter(s->s.toLowerCase(Locale.ROOT).startsWith(args[1].toLowerCase(Locale.ROOT))).collect(Collectors.toList());
        return Collections.emptyList();
    }
}
