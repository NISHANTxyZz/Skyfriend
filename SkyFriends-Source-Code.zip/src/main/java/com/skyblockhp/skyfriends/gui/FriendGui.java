package com.skyblockhp.skyfriends.gui;

import com.skyblockhp.skyfriends.SkyFriends;
import com.skyblockhp.skyfriends.data.FriendRepository;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.*;

public final class FriendGui implements Listener {
    private final SkyFriends plugin; private final FriendRepository repo;
    private final Map<UUID,Integer> pages=new HashMap<>();
    private final Map<UUID,String> view=new HashMap<>();
    private final Map<Integer,UUID> itemTargets=new HashMap<>();

    public FriendGui(SkyFriends plugin,FriendRepository repo){this.plugin=plugin;this.repo=repo;}

    public void openFriends(Player p,int page){
        Inventory inv=Bukkit.createInventory(null,54,SkyFriends.color(plugin.getConfig().getString("settings.gui-title","&8Friends")+" &7- "+(page+1)));
        List<UUID> friends=repo.friends(p.getUniqueId(),false);
        int start=Math.max(0,page*45),end=Math.min(friends.size(),start+45);
        for(int i=start;i<end;i++){
            UUID id=friends.get(i);OfflinePlayer op=Bukkit.getOfflinePlayer(id);
            ItemStack head=new ItemStack(Material.PLAYER_HEAD);
            SkullMeta meta=(SkullMeta)head.getItemMeta();meta.setOwningPlayer(op);
            boolean online=Bukkit.getPlayer(id)!=null;
            String nickname=repo.nickname(p.getUniqueId(),id);if(nickname==null||nickname.isBlank())nickname=repo.knownName(id);
            meta.setDisplayName(SkyFriends.color((online?"&a":"&7")+nickname+(repo.isBest(p.getUniqueId(),id)?" &6★":"")));
            meta.setLore(List.of(SkyFriends.color(online?"&aOnline":"&7Offline"),SkyFriends.color("&eLeft-click: manage friend"),SkyFriends.color("&7Right-click: remove friend")));
            head.setItemMeta(meta);inv.setItem(i-start,head);
        }
        inv.setItem(45,item(Material.ARROW,"&ePrevious page",List.of("&7Click to go back")));
        inv.setItem(49,item(Material.NETHER_STAR,"&6Friend requests",List.of("&eClick to view requests")));
        inv.setItem(50,item(Material.COMPARATOR,"&bPrivacy settings",List.of("&eClick to manage privacy")));
        inv.setItem(53,item(Material.ARROW,"&eNext page",List.of("&7Click to go forward")));
        pages.put(p.getUniqueId(),page);view.put(p.getUniqueId(),"friends");
        p.openInventory(inv);
    }

    public void openPrivacy(Player p){
        Inventory inv=Bukkit.createInventory(null,27,SkyFriends.color(plugin.getConfig().getString("settings.privacy-title","&8Friend Privacy")));
        boolean requests=repo.requestsEnabled(p.getUniqueId());
        boolean notifications=repo.notificationsEnabled(p.getUniqueId());
        inv.setItem(11,item(requests?Material.LIME_DYE:Material.GRAY_DYE,requests?"&aFriend requests: ON":"&cFriend requests: OFF",List.of("&7Click to toggle")));
        inv.setItem(15,item(notifications?Material.BELL:Material.BARRIER,notifications?"&aNotifications: ON":"&cNotifications: OFF",List.of("&7Click to toggle")));
        inv.setItem(22,item(Material.ARROW,"&eBack to friends",List.of("&7Return to friend list")));
        view.put(p.getUniqueId(),"privacy");p.openInventory(inv);
    }

    private ItemStack item(Material material,String name,List<String> lore){
        ItemStack item=new ItemStack(material);ItemMeta meta=item.getItemMeta();meta.setDisplayName(SkyFriends.color(name));meta.setLore(lore.stream().map(SkyFriends::color).toList());item.setItemMeta(meta);return item;
    }

    @EventHandler public void onClick(InventoryClickEvent e){
        if(!(e.getWhoClicked() instanceof Player p))return;
        String mode=view.get(p.getUniqueId());if(mode==null)return;
        e.setCancelled(true);if(e.getClickedInventory()==null||e.getClickedInventory()!=e.getView().getTopInventory())return;
        int slot=e.getRawSlot();
        if(mode.equals("privacy")){
            if(slot==11){boolean on=repo.toggleRequests(p.getUniqueId(),p.getName());p.sendMessage(plugin.message(on?"toggle-on":"toggle-off"));openPrivacy(p);}
            else if(slot==15){boolean on=repo.toggleNotifications(p.getUniqueId(),p.getName());p.sendMessage(plugin.message(on?"notifications-on":"notifications-off"));openPrivacy(p);}
            else if(slot==22)openFriends(p,0);
            return;
        }
        if(slot==45){openFriends(p,Math.max(0,pages.getOrDefault(p.getUniqueId(),0)-1));return;}
        if(slot==49){p.closeInventory();p.performCommand("friend requests");return;}
        if(slot==50){openPrivacy(p);return;}
        if(slot==53){openFriends(p,pages.getOrDefault(p.getUniqueId(),0)+1);return;}
        if(slot>=0&&slot<45){
            int page=pages.getOrDefault(p.getUniqueId(),0);List<UUID> list=repo.friends(p.getUniqueId(),false);int idx=page*45+slot;
            if(idx>=list.size())return;UUID target=list.get(idx);
            if(e.isRightClick()){
                repo.removeFriend(p.getUniqueId(),target);p.sendMessage(plugin.message("friend-removed").replace("%player%",repo.knownName(target)));openFriends(p,page);
            }else{
                repo.toggleBest(p.getUniqueId(),target);p.sendMessage(SkyFriends.color(repo.isBest(p.getUniqueId(),target)?"&aMarked as best friend.":"&eBest friend removed."));openFriends(p,page);
            }
        }
    }

    @EventHandler public void onClose(InventoryCloseEvent e){
        if(e.getPlayer() instanceof Player p){
            // Keep mode while switching between plugin menus; remove after closing a menu fully on next interaction is unnecessary.
            // A stale mode is harmless because the handler checks the currently clicked top inventory.
            view.remove(p.getUniqueId());
        }
    }
}
